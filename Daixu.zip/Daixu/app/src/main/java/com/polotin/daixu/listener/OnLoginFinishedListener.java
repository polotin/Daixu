package com.polotin.daixu.listener;

public interface OnLoginFinishedListener {

    void onLoginFailed();

    void onInternetError();
}
