package com.polotin.daixu.presenter;

public interface IValidatePresenter {

    public void checkValidationCode(String validationCode);

    public void sendMessage();
}
