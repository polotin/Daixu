package com.polotin.daixu.view;

public interface IValidateView {

    public void handleMessage(int msg);

    public void sendMessageResult(String msg);
}
