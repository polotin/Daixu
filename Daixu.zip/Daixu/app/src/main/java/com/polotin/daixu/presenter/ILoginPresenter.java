package com.polotin.daixu.presenter;

public interface ILoginPresenter {

    public void sendMsg(String phoneNumber);

}
