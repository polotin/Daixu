package com.polotin.daixu.values;

public class Msg {
    public static final int ACTION_SEND_MESSAGE = 3000;

    public static final int CHECK_VALIDATION_TRUE = 4000;
    public static final int CHECK_VALIDATION_FALSE = 4001;
}
