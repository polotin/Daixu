package com.polotin.daixu.presenter;

public interface IRegisterPresenter {
    public void sendMessage(String phoneNumber);

}
