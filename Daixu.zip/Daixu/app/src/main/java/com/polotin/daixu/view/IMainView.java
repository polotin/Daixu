package com.polotin.daixu.view;

public interface IMainView {
}
