package com.polotin.daixu.values;

public class NeteaseIM {
    public static final int MSG_RETURN_CODE_200 = 200;
    public static final int MSG_RETURN_CODE_315 = 315;
    public static final int MSG_RETURN_CODE_403 = 403;
    public static final int MSG_RETURN_CODE_404 = 404;
    public static final int MSG_RETURN_CODE_413 = 413;
    public static final int MSG_RETURN_CODE_414 = 414;
    public static final int MSG_RETURN_CODE_500 = 500;

    public static final String MSG_200 = "200";
    public static final String MSG_315 = "315";
    public static final String MSG_403 = "403";
    public static final String MSG_404 = "404";
    public static final String MSG_413 = "413";
    public static final String MSG_414 = "414";
    public static final String MSG_500 = "500";

}
